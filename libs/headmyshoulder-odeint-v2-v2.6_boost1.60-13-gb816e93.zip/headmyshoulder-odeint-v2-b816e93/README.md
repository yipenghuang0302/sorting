[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/headmyshoulder/odeint-v2/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

odeint is a highly flexible library for solving ordinary differential equations.
